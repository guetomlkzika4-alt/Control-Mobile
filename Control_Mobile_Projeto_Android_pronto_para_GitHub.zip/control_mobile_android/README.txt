Control Mobile - projeto Android (WebView)

O HTML fornecido foi incluído em app/src/main/assets/index.html.
O app abre esse painel em uma WebView Android.

Para gerar o APK:
1. Abra esta pasta no Android Studio.
2. Aguarde a sincronização do Gradle e a instalação do Android SDK 35 (se solicitado).
3. Use Build > Build APK(s).
4. O APK de debug ficará normalmente em app/build/outputs/apk/debug/app-debug.apk.

Observação: o HTML carrega Tailwind, Font Awesome e fontes por CDN, portanto esses elementos visuais precisam de internet.
A tela de otimização e alguns valores do painel são simulações do HTML; não liberam RAM, limpam cache do Android nem leem sensores de hardware reais.
